import React from 'react'

export default function Title_Season(props) {
    return (
        <div className='Title_Season mt-5'>
            <h2>{props.title}</h2>
        </div>
    )
}
