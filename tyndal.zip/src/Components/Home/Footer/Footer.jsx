import React from 'react'
import { Col, Container, Nav, Row } from 'react-bootstrap'
import '../Home.css'
import { BsFacebook, BsTwitter, BsInstagram, BsYoutube } from 'react-icons/bs'
import { FcGoogle } from 'react-icons/fc'
let names =  [ 'amir' , 'ali' , 'mmd' , 'amir'] ;
let ssc = new Set(names)
console.log(ssc)

export default function Footer() {
    return (
        <Container>
            <Row className='justify-content-between  '>
                <Col sm={12} xs={12} md={3} lg={2}>
                    <ul>
                        <span>شرکت</span>

                        <li>درباره</li>
                        <li>مشاغل</li>
                        <li>مطبوعات</li>
                        <li>تماس</li>
                        <li>مقررات</li>
                        <li>سیاست حفظ حریم خصوصی</li>
                        <li>خط مشی کوکی</li>
                        <li>تنظیمات کوکی</li>

                    </ul>
                </Col>
                <Col sm={12} xs={12} md={3} lg={2}>

                    <ul>
                        <span>همکاران</span>

                        <li>فروشندگان</li>
                        <li>پنل فروشندگی</li>
                        <li>دیزاینر</li>
                        <li>تحضیلات</li>
                    </ul>
                </Col>
                <Col sm={12} xs={12} md={3} lg={2}>

                    <ul>
                        <span>پشتیبانی</span>

                        <li>انجمن</li>
                        <li>پشتیبانی آنلاین</li>

                    </ul>
                </Col>
                <Col sm={12} xs={12} md={3} lg={2}>

                    <ul>
                        <span>منبع</span>

                        <li>وبلاگ تیندال</li>
                        <li>مرکز اصلی</li>
                        <li>داستان های موفقیت</li>
                        <li>اسناد توسعه دهنده</li>
                    </ul>
                </Col>
                <Col sm={12} xs={12} md={3} lg={2}>

                    <ul>
                        <span>محصولات</span>

                        <li>وبسایت</li>
                        <li>فروشگاه آنلاین</li>
                        <li>استدیو عکس</li>
                        <li>بازاریابی</li>
                        <li>امکانات</li>
                        <li>تم</li>
                        <li>تعرفه</li>
                        <li>برنامه موبایل</li>



                    </ul>
                </Col>

            </Row>
            <Row className='End-Footer'>
                <Col className='copy-right'><span>تیندال 2020 - 2033</span></Col>
                <Col className='social-media'>
                    <div><BsFacebook /></div>
                    <div><BsTwitter /></div>
                    <div><BsInstagram /></div>
                    <div><BsYoutube /></div>
                    <div><FcGoogle /></div>

                </Col>


            </Row>

        </Container>
    )
}
