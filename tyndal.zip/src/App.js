import './App.css';
import Home from './Components/Home/Home';

function App() {
  return (
    <div className="">
      <Home></Home>
    </div>
  );
}

export default App;
